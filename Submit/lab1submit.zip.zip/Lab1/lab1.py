# Sample Coding Questions 01 Week 01
# Name: Uzma Shaikh
# Student# 101504303
# GitHub @uzmashxxxikh

# Question 1: Define an array
my_array = [1, 4, 7, 9]

# Question 2: Order of Operations
a, b, c, d = 1, 2, 3, 4
e = (a * c) - (b / d)

# Question 3: Formatting
temperature = 32.6
print("The temperature today is: {:.3f} degrees Celsius".format(temperature))


# Question 4: User input and adding 22 years
user_age = int(input("Enter your age: "))
user_age += 22
print("Your new age after adding 22 years is:", user_age)